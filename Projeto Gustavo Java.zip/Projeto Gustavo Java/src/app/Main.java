package app;

public class Main {

    public static void main(String[] args) {
        Cerveja cerveja = new Cerveja("Skol");
        
        cerveja.setLote(452);
        cerveja.setEmbalagem("Vidro");
        cerveja.setTransporte("Caminhão");
        cerveja.setValorVenda(5);
        cerveja.setRotulo("PAPEL");
        
        System.out.println(cerveja.getMarca());
        System.out.println("-------------");
        System.out.println("LOTE= " + cerveja.getLote());
        System.out.println("MATERIAL EMBALAGEM = " + cerveja.getEmbalagem());
        System.out.println("MEIO DE TRANSPORTE = " + cerveja.getTransporte());
        System.out.println("VALOR = R$ " + cerveja.getValorVenda());
        System.out.println("MATERIAL ROTULO = " + cerveja.getRotulo());
        System.out.println("-------------");
        

    }
}
