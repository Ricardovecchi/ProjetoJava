/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package app;

/**
 *
 * @author aluno
 */
public class MateriaPrima extends Produto{
    private String agua;
    private String cevada;
    private String lupulo;

    public String getAgua() {
        return agua;
    }

    public void setAgua(String agua) {
        this.agua = agua;
    }

    public String getCevada() {
        return cevada;
    }

    public void setCevada(String cevada) {
        this.cevada = cevada;
    }

    public String getLupulo() {
        return lupulo;
    }

    public void setLupulo(String lupulo) {
        this.lupulo = lupulo;
    }
    
    
}
